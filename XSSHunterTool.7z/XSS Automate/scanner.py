import requests
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from bs4 import BeautifulSoup

def load_payloads(filepath):
    with open(filepath, 'r') as f:
        return [line.strip() for line in f if line.strip()]

def inject_payload(url, param, payload):
    parsed_url = urlparse(url)
    query_params = parse_qs(parsed_url.query)

    if param not in query_params:
        return None

    query_params[param] = payload
    new_query = urlencode(query_params, doseq=True)
    new_url = urlunparse(parsed_url._replace(query=new_query))
    return new_url

def scan_url(url, payloads):
    parsed = urlparse(url)
    query_params = parse_qs(parsed.query)

    print(f"[+] Scanning {url}")
    for param in query_params:
        for payload in payloads:
            test_url = inject_payload(url, param, payload)
            try:
                response = requests.get(test_url, timeout=5)
                if payload in response.text:
                    print(f"[!] Reflected XSS Found!\nParam: {param}\nPayload: {payload}\nURL: {test_url}\n")
            except requests.exceptions.RequestException as e:
                print(f"[-] Request failed: {e}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python scanner.py <URL>")
        exit()

    target_url = sys.argv[1]
    payloads = load_payloads("payloads.txt")
    scan_url(target_url, payloads)
